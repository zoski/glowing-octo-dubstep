<!-- This code is taken from http://twitter.github.com/bootstrap/examples/hero.html -->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body>


        <div class="container">

            <div class="hero-unit">
            	<?php echo '<h1>Hello, world !</h1>'; ?>
				<p>A l'intérieur de cette boîte, affichez en PHP dans une balise de titre1 la phrase "Hello, World !"</p>
            </div>

            <hr>

            <footer>
                <p>&copy; PHP - Exercice 1 - Affichage dynamique !</p>
            </footer>

        </div> <!-- /container -->

    </body>
</html>
